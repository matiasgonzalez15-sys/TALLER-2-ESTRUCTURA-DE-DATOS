#pragma once
#include "ArbolDecision.h"
#include "Paciente.h"
#include "NodeServicios.h"
#include "ServicioMedico.h"
#include "ColaPacientes.h"
#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
using namespace std;
class Hospital {
private:
    NodeServicios* servicios;
    ColaPacientes* filaEspera;
    ArbolDecision* arbol;
    ServicioMedico* crearServicioMedico(const string& nombre);
public:
    Hospital();
    void agregarPaciente(Paciente* p);
    bool existePaciente(const string& id);
    void crearPaciente(string linea);
    void mostrarDepartamentos();
    void añadirServicioMedico(ServicioMedico * servicio);
    void crearServicioMedico();
    void verDepartamento();

    void mostrarPacientes(); // ESTA FUNCION ES PARA MOSTRAR LOS PACIENTES Y SELECCIONAR CUANTOS QUIERE ATENDER
    ServicioMedico * buscarServicioMedico(const string & string);

    void atenderPacientes(int opcion); // AQUI YA LOS ATENDEMOS
    ~Hospital();
};