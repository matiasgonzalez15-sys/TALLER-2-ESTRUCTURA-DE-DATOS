#pragma once
#include "Paciente.h"


class NodoAVL {
public:
    Paciente* paciente;
    NodoAVL* izq;
    NodoAVL* der;
    int altura;

    explicit NodoAVL(Paciente* p) : paciente(p), izq(nullptr), der(nullptr), altura(1) {}

    [[nodiscard]] Paciente * paciente1() const {
        return paciente;
    }

    [[nodiscard]] NodoAVL * izq1() const {
        return izq;
    }

    [[nodiscard]] NodoAVL * der1() const {
        return der;
    }

    [[nodiscard]] int altura1() const {
        return altura;
    }
};
