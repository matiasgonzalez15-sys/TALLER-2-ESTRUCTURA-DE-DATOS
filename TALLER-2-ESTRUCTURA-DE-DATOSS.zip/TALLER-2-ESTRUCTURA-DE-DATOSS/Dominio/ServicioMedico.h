#include "NodePacientes.h"
#include "ArbolAVL.h"
#include <iostream>
#pragma once

class ServicioMedico {
protected:
    string nombre;
     ArbolAVL* arbolPacientes;
public:

    ServicioMedico(string nombre) {
        this->nombre = nombre;
        this->arbolPacientes = new ArbolAVL();
    };



    string getNombre() const{
        return this->nombre;
    }



    
    virtual ~ServicioMedico() {
        delete arbolPacientes;
    }



    void mostrarDetalle(int opcion) {
        switch (opcion) {
            case 1:
                arbolPacientes->mostrarInorden();
                break;
            case 2:
                arbolPacientes->mostrarPreorden();
                break;
            case 3:
                arbolPacientes->mostrarPostorden();
                break;
            case 4:
                cout << "Total: "
                     << arbolPacientes->total() << endl;
                arbolPacientes->mostrarBalances();
                break;
            default:
                cout << "Opcion invalida." << endl;
        }
    }

    Paciente* buscarPorId(const string& id) const {
        return arbolPacientes->buscarPorId(id);
    }

    bool existePaciente(const string& id) const {
        return arbolPacientes->existe(id);
    }



    void mostrarPacientes() const {
        arbolPacientes->mostrarInorden();
    }



    void mostrarDetalle(int opcion) const {
        switch (opcion) {
            case 1:
                arbolPacientes->mostrarInorden();
                break;

            case 2:
                arbolPacientes->mostrarPreorden();
                break;

            case 3:
                arbolPacientes->mostrarPostorden();
                break;

            case 4:
                cout << "Total de pacientes: "
                     << arbolPacientes->total() << endl;
                arbolPacientes->mostrarBalances();
                break;

            default:
                cout << "Opcion invalida." << endl;
                break;
        }
    }




    virtual bool agregarPaciente(Paciente* p) {
        if (p == nullptr) {
            cout << "ERROR: paciente nulo" << endl;
            return false;
        }
        if (arbolPacientes == nullptr) {
            cout << "ERROR: el arbol de pacientes es nulo" << endl;
            return false;
        }
        bool resultado = arbolPacientes->insertar(p);
        return resultado;
    }
};





class Urgencia : public ServicioMedico {
public:
    Urgencia() : ServicioMedico("Urgencia") {};
};

class MedicinaGeneral : public ServicioMedico {
public:
    MedicinaGeneral() : ServicioMedico("MedicinaGeneral") {};
};

class Cardiologia : public ServicioMedico {
public:
    Cardiologia() : ServicioMedico("Cardiologia") {};
};

class Neurologia : public ServicioMedico {
public:
    Neurologia() : ServicioMedico("Neurologia") {};
};

class Traumatologia : public ServicioMedico {
public:
    Traumatologia() : ServicioMedico("Traumatologia") {};
};
class Cirugia : public ServicioMedico {
public:
    Cirugia() : ServicioMedico("Cirugia") {};
};
class Pediatria : public ServicioMedico {
public:
    Pediatria() : ServicioMedico("Pediatria") {};
};
class Hospitalizacion : public ServicioMedico {
public:
    Hospitalizacion() : ServicioMedico("Hospitalizacion") {};
};


