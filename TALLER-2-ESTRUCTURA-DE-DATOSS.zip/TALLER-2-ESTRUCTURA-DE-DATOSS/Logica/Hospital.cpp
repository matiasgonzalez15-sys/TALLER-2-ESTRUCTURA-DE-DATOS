#include "../Dominio\Hospital.h"
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

Hospital::Hospital() {
    this -> servicios = nullptr;
    this-> filaEspera = new ColaPacientes();
    this->arbol = new ArbolDecision();
    crearServicioMedico();
}

void Hospital::añadirServicioMedico(ServicioMedico* s) { // se agregan al nodo de los servicios
    NodeServicios* servicio = new NodeServicios(s);

    if (this -> servicios == nullptr) {
        this -> servicios = servicio;
    }
    else {
        NodeServicios* cursor = this -> servicios;
        while (cursor -> getNext() != nullptr) {
            cursor = cursor -> getNext();
        }
        cursor -> setNext(servicio);
    }
}

void Hospital::crearServicioMedico() { // tenemos que crear aqui los servicios medicos
    ServicioMedico* u = new Urgencia();
    añadirServicioMedico(u);
    ServicioMedico* mg = new MedicinaGeneral();
    añadirServicioMedico(mg);
    ServicioMedico* c = new Cardiologia();
    añadirServicioMedico(c);
    ServicioMedico* n = new Neurologia();
    añadirServicioMedico(n);
    ServicioMedico* t = new Traumatologia();
    añadirServicioMedico(t);
    ServicioMedico* cir = new Cirugia();
    añadirServicioMedico(cir);
    ServicioMedico* p = new Pediatria();
    añadirServicioMedico(p);
    ServicioMedico* hosp = new Hospitalizacion();
    añadirServicioMedico(hosp);
}

void Hospital::agregarPaciente(Paciente *p) { // se agrega el paciente a la cola
    if (!existePaciente(p->getId())) {
        filaEspera->push(p);
    } else {
        cout << p->getId() << " ya se encuentra en la fila" << endl;
    }
}


bool Hospital::existePaciente(const string &id) { // verificamos si el paciente ya existe
    if (filaEspera->existe(id)) {
        return true;
    }
    return false;
}


void Hospital::crearPaciente(string linea) { // creamos pacientes y se mandan a la fila de espera
    stringstream ss(linea);
    string id, nombre, edadString, tempStr, presionStr, dolorStr, tipoDolor, traumaStr, sintNeuStr, cirugiaStr,
            diasHospStr;
    getline(ss, id, ';');
    getline(ss, nombre, ';');
    getline(ss, edadString, ';');
    getline(ss, tempStr, ';');
    getline(ss, presionStr, ';');
    getline(ss, dolorStr, ';');
    getline(ss, tipoDolor, ';');
    getline(ss, traumaStr, ';');
    getline(ss, sintNeuStr, ';');
    getline(ss, cirugiaStr, ';');
    getline(ss, diasHospStr, ';');

    int edad = stoi(edadString);
    float temp = stof(tempStr);
    float presion = stof(presionStr);
    float dolor = stof(dolorStr);
    int diasHosp = stoi(diasHospStr);
    bool existeP = existePaciente(id);
    if (!existeP) {
        Paciente* paciente = new Paciente(id, nombre, edad, temp, presion, dolor, tipoDolor, traumaStr,
            sintNeuStr, cirugiaStr, diasHosp);
        agregarPaciente(paciente);
    }
}

void Hospital::mostrarDepartamentos() {
    cout << "\n=== DEPARTAMENTOS DISPONIBLES ===" << endl;

    NodeServicios* cursor = this->servicios;
    int contador = 1;

    // Mostrar los departamentos numerados
    while (cursor != nullptr) {
        cout << contador << ". "
             << cursor->getServicio()->getNombre() << endl;

        cursor = cursor->getNext();
        contador++;
    }

    int opcion;
    cout << "\nSeleccione el departamento: ";
    cin >> opcion;

    // Validar que se ingrese un numero
    if (cin.fail()) {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "Entrada invalida. Debe ingresar un numero." << endl;
        return;
    }

    // Validar que el numero corresponda a un departamento
    if (opcion < 1 || opcion >= contador) {
        cout << "Opcion invalida." << endl;
        return;
    }

    // Buscar el departamento seleccionado
    cursor = this->servicios;

    for (int i = 1; i < opcion; i++) {
        cursor = cursor->getNext();
    }

    ServicioMedico* servicio = cursor->getServicio();

    cout << "\n--- Departamento: "
         << servicio->getNombre() << " ---" << endl;

    cout << "1. Mostrar Inorden" << endl;
    cout << "2. Mostrar Preorden" << endl;
    cout << "3. Mostrar Postorden" << endl;
    cout << "4. Ver balances y total de pacientes" << endl;

    int opt;
    cout << "Seleccione como visualizar: ";
    cin >> opt;

    if (cin.fail()) {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "Entrada invalida." << endl;
        return;
    }

    cout << endl;
    servicio->mostrarDetalle(opt);
}



ServicioMedico* Hospital::buscarServicioMedico(const string& nombre) { //gepeteado
    NodeServicios* cursor = servicios;

    while (cursor != nullptr) {
        ServicioMedico* servicio = cursor->getServicio();

        if (servicio != nullptr &&
            servicio->getNombre() == nombre) {
            return servicio;
            }

        cursor = cursor->getNext();
    }

    return nullptr;
}

void Hospital::mostrarPacientes() { //gepeteado
    cout << "\nPacientes en espera: "
         << filaEspera->size() << endl;
}












void Hospital::atenderPacientes(int opcion) {
    int atendidos = 0;

    while (atendidos < opcion && !filaEspera->empty()) {
        Paciente* p = filaEspera->front();
        if (p == nullptr) { return; }
        filaEspera->pop();

        string nombreServicio = arbol->determinarServicio(p);

        ServicioMedico* servicioDestino = buscarServicioMedico(nombreServicio);
        if (servicioDestino != nullptr) {
            if (servicioDestino->agregarPaciente(p)) {
                cout << "Paciente " << p->getNombre()
                     << " clasificado en: " << nombreServicio << endl;


                atendidos++;
            } else {

                delete p;
                cout << "No se pudo registrar al paciente." << endl;
            }
        } else {
            cout << "Error interno: Servicio '" << nombreServicio << "' no encontrado." << endl;
            delete p;
        }
    }

    cout << "\nSe atendieron " << atendidos << " pacientes de la fila." << endl;
}
Hospital::~Hospital() {
    NodeServicios* actualS= this-> servicios;
    while (actualS != nullptr) {
        NodeServicios* temp = actualS;
        actualS = actualS->getNext();
        delete temp;
    }
    delete this -> filaEspera;
}

