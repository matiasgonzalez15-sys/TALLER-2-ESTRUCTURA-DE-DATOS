
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "C:/Users/chris/CLionProjects/TALLER-2-ESTRUCTURA-DE-DATOSS/Logica/ArbolAVL.cpp" "CMakeFiles/untitled1.dir/Logica/ArbolAVL.cpp.obj" "gcc" "CMakeFiles/untitled1.dir/Logica/ArbolAVL.cpp.obj.d"
  "C:/Users/chris/CLionProjects/TALLER-2-ESTRUCTURA-DE-DATOSS/Logica/ArbolDecision.cpp" "CMakeFiles/untitled1.dir/Logica/ArbolDecision.cpp.obj" "gcc" "CMakeFiles/untitled1.dir/Logica/ArbolDecision.cpp.obj.d"
  "C:/Users/chris/CLionProjects/TALLER-2-ESTRUCTURA-DE-DATOSS/Logica/ColaPacientes.cpp" "CMakeFiles/untitled1.dir/Logica/ColaPacientes.cpp.obj" "gcc" "CMakeFiles/untitled1.dir/Logica/ColaPacientes.cpp.obj.d"
  "C:/Users/chris/CLionProjects/TALLER-2-ESTRUCTURA-DE-DATOSS/Logica/Hospital.cpp" "CMakeFiles/untitled1.dir/Logica/Hospital.cpp.obj" "gcc" "CMakeFiles/untitled1.dir/Logica/Hospital.cpp.obj.d"
  "C:/Users/chris/CLionProjects/TALLER-2-ESTRUCTURA-DE-DATOSS/Logica/main.cpp" "CMakeFiles/untitled1.dir/Logica/main.cpp.obj" "gcc" "CMakeFiles/untitled1.dir/Logica/main.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
