file(REMOVE_RECURSE
  "CMakeFiles/untitled1.dir/Logica/ArbolAVL.cpp.obj"
  "CMakeFiles/untitled1.dir/Logica/ArbolAVL.cpp.obj.d"
  "CMakeFiles/untitled1.dir/Logica/ArbolDecision.cpp.obj"
  "CMakeFiles/untitled1.dir/Logica/ArbolDecision.cpp.obj.d"
  "CMakeFiles/untitled1.dir/Logica/ColaPacientes.cpp.obj"
  "CMakeFiles/untitled1.dir/Logica/ColaPacientes.cpp.obj.d"
  "CMakeFiles/untitled1.dir/Logica/Hospital.cpp.obj"
  "CMakeFiles/untitled1.dir/Logica/Hospital.cpp.obj.d"
  "CMakeFiles/untitled1.dir/Logica/main.cpp.obj"
  "CMakeFiles/untitled1.dir/Logica/main.cpp.obj.d"
  "libuntitled1.dll.a"
  "untitled1.exe"
  "untitled1.exe.manifest"
  "untitled1.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/untitled1.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
